from datetime import datetime
from typing import Optional, List
from sqlmodel import Field, SQLModel, Relationship

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    email: str = Field(unique=True, index=True)
    hashed_password: str
    full_name: Optional[str] = None
    job_title: Optional[str] = None
    organization: Optional[str] = None
    is_pro: bool = False
    
    settings: Optional["Settings"] = Relationship(back_populates="user")
    subscriptions: List["Subscription"] = Relationship(back_populates="user")
    data_sources: List["DataSource"] = Relationship(back_populates="user")

class Settings(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id")
    theme: str = "light"
    notifications: bool = True
    ai_privacy_mode: bool = False
    language: str = "English (US)"
    currency: str = "USD ($)"
    insight_frequency: str = "Real-time"
    two_factor_enabled: bool = False
    
    user: Optional[User] = Relationship(back_populates="settings")

class Subscription(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id")
    plan_name: str
    price: str
    dashboards_used: int = 0
    dashboards_limit: int = 20
    ai_credits_used: int = 0
    ai_credits_limit: int = 1000
    status: str = "Active"
    
    user: Optional[User] = Relationship(back_populates="subscriptions")

class DataSource(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: Optional[int] = Field(foreign_key="user.id", nullable=True) # Allow null for global/demo data
    filename: str
    file_path: str
    upload_date: datetime = Field(default_factory=datetime.utcnow)
    status: str = "Processed"
    row_count: int = 0
    
    user: Optional[User] = Relationship(back_populates="data_sources")

class Transaction(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    # user_id could be added if we want per-user transactions, keeping it simple for now
    transaction_id_str: str = Field(unique=True) # e.g. #TX-89210
    customer_name: str
    product_category: str
    amount: float
    status: str
    date: datetime

class Metric(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    label: str # e.g. "Total Revenue"
    value: str # e.g. "$1,284,000"
    trend_percentage: float # e.g. 12.5
    trend_direction: str # "up" or "down"
    period: str = "Monthly"
