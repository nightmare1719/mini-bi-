from sqlmodel import Session, select
from backend.database import engine, create_db_and_tables
from backend.models import User, Settings, Subscription, Metric, Transaction, DataSource
from backend.auth import get_password_hash
from datetime import datetime

def seed_data():
    create_db_and_tables()
    
    with Session(engine) as session:
        # 1. Check if user exists
        user = session.exec(select(User).where(User.email == "alex.rivera@insightflow.ai")).first()
        if not user:
            print("Creating seed user...")
            hashed_pw = get_password_hash("password123")
            user = User(
                email="alex.rivera@insightflow.ai",
                hashed_password=hashed_pw,
                full_name="Alex Rivera",
                job_title="Senior Data Analyst",
                organization="Quantum Analytics Group",
                is_pro=True
            )
            session.add(user)
            session.commit()
            session.refresh(user)

            # Settings
            settings = Settings(user_id=user.id, theme="light", notifications=True)
            session.add(settings)
            
            # Subscription
            sub = Subscription(user_id=user.id, plan_name="Pro Annual", price="$240 / year", dashboards_used=12, ai_credits_used=850)
            session.add(sub)
        
        # 2. Metrics (Executive Overview)
        if not session.exec(select(Metric)).first():
            print("Seeding metrics...")
            metrics = [
                Metric(label="Total Revenue", value="$1,284,000", trend_percentage=12.5, trend_direction="up"),
                Metric(label="Active Users", value="48,291", trend_percentage=4.2, trend_direction="up"),
                Metric(label="Conversion Rate", value="3.24%", trend_percentage=0.8, trend_direction="down"),
            ]
            for m in metrics:
                session.add(m)
        
        # 3. Transactions (Date formatted for display)
        if not session.exec(select(Transaction)).first():
            print("Seeding transactions...")
            transactions = [
                Transaction(transaction_id_str="#TX-89210", customer_name="Alex Rivera", product_category="Electronics", amount=1200.00, status="COMPLETED", date=datetime.now()),
                Transaction(transaction_id_str="#TX-89211", customer_name="Sarah Jenkins", product_category="Software", amount=499.00, status="PROCESSING", date=datetime.now()),
                Transaction(transaction_id_str="#TX-89212", customer_name="Michael Chen", product_category="Furniture", amount=2840.00, status="PENDING", date=datetime.now()),
                Transaction(transaction_id_str="#TX-89213", customer_name="Emma Wilson", product_category="Electronics", amount=120.00, status="COMPLETED", date=datetime.now()),
            ]
            for t in transactions:
                session.add(t)

        # 4. Data Sources (Recent Uploads)
        if not session.exec(select(DataSource)).first():
            print("Seeding data sources...")
            datasources = [
                DataSource(user_id=user.id, filename="sales_q3_report.csv", file_path="/tmp/sales.csv", status="Processed", row_count=15000),
                DataSource(user_id=user.id, filename="marketing_metrics_2023.csv", file_path="/tmp/marketing.csv", status="Processed", row_count=12400),
            ]
            for d in datasources:
                session.add(d)

        session.commit()
        print("Seeding complete!")

if __name__ == "__main__":
    seed_data()
