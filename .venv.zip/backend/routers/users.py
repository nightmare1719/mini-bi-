from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from backend.database import get_session
from backend.models import User, Settings, Subscription
from backend.schemas import UserRead, SettingsUpdate
from backend.auth import get_current_user

router = APIRouter(prefix="/api/user", tags=["user"])

@router.get("/me", response_model=UserRead)
def read_users_me(current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    # Refresh to get relationships
    # The relationships might be missing if not eager loaded, but SQLModel usually handles lazy loading if session is active
    # For Pydantic response, we might need to explicitly join or trust lazy load
    return current_user

@router.put("/me/settings", response_model=Settings)
def update_settings(settings_update: SettingsUpdate, current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    user_settings = session.exec(select(Settings).where(Settings.user_id == current_user.id)).first()
    if not user_settings:
        user_settings = Settings(user_id=current_user.id)
        session.add(user_settings)
    
    settings_data = settings_update.dict(exclude_unset=True)
    for key, value in settings_data.items():
        setattr(user_settings, key, value)
    
    session.add(user_settings)
    session.commit()
    session.refresh(user_settings)
    return user_settings
