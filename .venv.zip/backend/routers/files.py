import shutil
import os
from typing import List
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlmodel import Session, select
from backend.database import get_session
from backend.models import User, DataSource
from backend.auth import get_current_user
from datetime import datetime

router = APIRouter(prefix="/api/files", tags=["files"])

UPLOAD_DIR = "uploads"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

@router.post("/upload")
async def upload_file(file: UploadFile = File(...), current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    file_location = f"{UPLOAD_DIR}/{file.filename}"
    try:
        with open(file_location, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not save file: {e}")

    row_count = 0
    try:
        if file.filename.endswith('.csv'):
            with open(file_location, "r", encoding="utf-8") as f:
                row_count = sum(1 for line in f) - 1 # Subtract header
                if row_count < 0: row_count = 0
    except Exception:
        row_count = 0

    # Create DataSource entry
    data_source = DataSource(
        user_id=current_user.id,
        filename=file.filename,
        file_path=file_location,
        status="Analyzed", 
        row_count=row_count
    )
    session.add(data_source)
    session.commit()
    session.refresh(data_source)

    return {"filename": file.filename, "status": "success", "id": data_source.id}

@router.get("/recent", response_model=List[DataSource])
def get_recent_uploads(limit: int = 5, current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    uploads = session.exec(select(DataSource).where(DataSource.user_id == current_user.id).order_by(DataSource.upload_date.desc()).limit(limit)).all()
    return uploads
