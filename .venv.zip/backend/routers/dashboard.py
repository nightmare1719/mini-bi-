from typing import List
from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from backend.database import get_session
from backend.models import User, Metric, Transaction
from backend.auth import get_current_user

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])

@router.get("/overview")
def get_overview_metrics(time_range: str = "30d", current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    # In a real app, this would aggregate from Transactions/Orders
    # For now, we return seed data or calculate simple aggregates
    metrics = session.exec(select(Metric)).all()
    
    if not metrics:
        # Fallback/Default if no seed data
        return [
            {"label": "Total Revenue", "value": "$0", "trend_percentage": 0, "trend_direction": "flat"},
            {"label": "Active Users", "value": "0", "trend_percentage": 0, "trend_direction": "flat"}
        ]
        
    # Simulate filtering logic
    factor = 1.0
    if time_range == "7d":
        factor = 0.25
    elif time_range == "90d":
        factor = 3.0
    elif time_range == "365d":
        factor = 12.0
        
    adjusted_metrics = []
    for m in metrics:
        # Clone to avoid modifying DB object in session
        new_m = m.model_copy()
        
        # Simple parsing and adjustment logic
        try:
            if "$" in new_m.value:
                 val = float(new_m.value.replace("$", "").replace(",", ""))
                 new_val = val * factor
                 new_m.value = f"${new_val:,.0f}"
            elif "%" in new_m.value:
                 # Don't scale percentages linear with time usually, but for demo:
                 pass 
            else:
                 # Users count
                 val = float(new_m.value.replace(",", ""))
                 new_val = val * factor
                 new_m.value = f"{new_val:,.0f}"
        except:
            pass
            
        adjusted_metrics.append(new_m)

    return adjusted_metrics

@router.get("/growth")
def get_growth_data(current_user: User = Depends(get_current_user)):
    # Mock data strictly matching the 'Revenue by Quarter' chart in 'AI advisor...html'
    return {
        "labels": ["Q1", "Q2", "Q3", "Q4 (Est)"],
        "datasets": [
            {"label": "Revenue", "data": [12000, 18000, 22000, 28000], "spike_index": 2, "spike_label": "+20% Spike"}
        ]
    }

@router.get("/channels")
def get_channel_distribution(current_user: User = Depends(get_current_user)):
    # Mock data for Donut chart
    return [
        {"label": "Direct Sales", "value": 70, "color": "primary"},
        {"label": "Social Media", "value": 25, "color": "purple"},
        {"label": "Affiliate", "value": 5, "color": "amber"}
    ]

@router.get("/transactions", response_model=List[Transaction])
def get_recent_transactions(limit: int = 5, current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    transactions = session.exec(select(Transaction).limit(limit)).all()
    return transactions
