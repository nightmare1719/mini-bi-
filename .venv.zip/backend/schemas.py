from typing import Optional, List
from pydantic import BaseModel
from backend.models import User, Settings, Subscription
from datetime import datetime

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None

class UserCreate(BaseModel):
    email: str
    password: str
    full_name: str
    job_title: Optional[str] = None
    organization: Optional[str] = None

class UserLogin(BaseModel):
    email: str
    password: str

class SettingsUpdate(BaseModel):
    theme: Optional[str] = None
    notifications: Optional[bool] = None
    ai_privacy_mode: Optional[bool] = None
    language: Optional[str] = None
    currency: Optional[str] = None
    insight_frequency: Optional[str] = None
    two_factor_enabled: Optional[bool] = None

class UserRead(BaseModel):
    id: int
    email: str
    full_name: Optional[str] = None
    job_title: Optional[str] = None
    organization: Optional[str] = None
    is_pro: bool
    settings: Optional[Settings] = None
    subscriptions: List[Subscription] = []
    
    class Config:
        orm_mode = True

class DashboardMetrics(BaseModel):
    total_revenue: str
    active_users: str
    conversion_rate: str
    revenue_trend: float
    users_trend: float
    conversion_trend: float

class FileUploadResponse(BaseModel):
    filename: str
    status: str
    message: str
