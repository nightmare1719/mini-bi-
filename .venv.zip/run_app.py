import uvicorn
import webbrowser
import threading
import time
import os
import sys

def open_browser():
    # Wait a few seconds for server to start
    time.sleep(2)
    print("Opening browser at http://localhost:8000")
    webbrowser.open("http://localhost:8000")

def main():
    # Start browser in a separate thread
    threading.Thread(target=open_browser, daemon=True).start()
    
    # Run the uvicorn server
    # We need to run it as a module since our app structure relies on it
    # But uvicorn.run expects an import string or app instance
    print("Starting AI Business Dashboard...")
    
    # Ensure we are in the correct directory (parent of backend)
    # Get the directory containing this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    
    # Add current dir to sys.path to ensure modules can be imported
    sys.path.append(script_dir)
    
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)

if __name__ == "__main__":
    main()
